package com.chitarraclassica.compositori;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.net.URLDecoder;

public class MainActivity extends Activity {

    private WebView web;
    private ValueCallback<Uri[]> sceltaFile;
    private static final int SCEGLI_FILE = 7;

    @Override
    protected void onCreate(Bundle stato) {
        super.onCreate(stato);
        web = new WebView(this);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setTextZoom(100);

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                return apriFuori(r.getUrl().toString());
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (sceltaFile != null) sceltaFile.onReceiveValue(null);
                sceltaFile = cb;
                try {
                    startActivityForResult(p.createIntent(), SCEGLI_FILE);
                } catch (Exception e) {
                    sceltaFile = null;
                    return false;
                }
                return true;
            }
        });

        if (stato != null) web.restoreState(stato);
        else web.loadUrl("file:///android_asset/index.html");
    }

    // Link esterni (YouTube, Google AI) nel browser; il file .txt si condivide
    private boolean apriFuori(String url) {
        if (url.startsWith("file:")) return false;
        try {
            if (url.startsWith("data:text/plain")) {
                String testo = URLDecoder.decode(url.substring(url.indexOf(',') + 1), "UTF-8");
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType("text/plain");
                i.putExtra(Intent.EXTRA_TEXT, testo);
                startActivity(Intent.createChooser(i, "Esporta elenco autori"));
            } else {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
            }
        } catch (Exception ignorato) { }
        return true;
    }

    @Override
    protected void onActivityResult(int req, int res, Intent dati) {
        if (req == SCEGLI_FILE && sceltaFile != null) {
            sceltaFile.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, dati));
            sceltaFile = null;
        } else {
            super.onActivityResult(req, res, dati);
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle b) {
        super.onSaveInstanceState(b);
        web.saveState(b);
    }

    @Override
    public void onBackPressed() {
        // Chiude prima i pannelli aperti (pagina autore, impostazioni, AI, esporta)
        web.evaluateJavascript(
            "(function(){var a=document.querySelector('#ov.on,#st.on,#ai.on,#ex.on');" +
            "if(a){a.classList.remove('on');return 'chiuso';}" +
            "var t=document.getElementById('tcp');if(t&&!t.hidden){t.hidden=true;return 'chiuso';}" +
            "return 'esci';})()",
            r -> { if (r != null && r.contains("esci")) MainActivity.super.onBackPressed(); });
    }
}
